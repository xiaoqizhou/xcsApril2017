# A great python library for reading and writing data.
import csv

# This is example code that loads each of the CSV files.
# Feel free to use this code in your solution. Don't forget
# to import csv
def main():
	peerGrades = loadPeerGrades()
	learningOutcomes = loadLearningOutcomes()
	backgrounds = loadBackgrounds()

	outputList(peerGrades)
	outputList(learningOutcomes)
	outputList(backgrounds)

# Example loading for the problem on peer grades. Returns
# the numbers in peerGrades.csv as a python list
def loadPeerGrades():
	grades = []
	reader = csv.reader(open('peerGrades.csv'))
	for row in reader:
		grades.append(float(row[0])) # make sure grades are numbers
	return grades


# Example loading for the problem on A/B testing.
# Returns a list of student data. Each student is a list
# with three elements: their id, their activity and their 
# learning outcome.
def loadLearningOutcomes():
	reader = csv.reader(open('learningOutcomes.csv'))
	# this line skips the header at the top of the csv
	header = reader.next()
	learningOutcomes = []
	for row in reader:
		studentId = row[0]
		activity = row[1]
		outcome = float(row[2]) # make sure outcome is a number!
		learningOutcomes.append([studentId, activity, outcome])
	return learningOutcomes


# Example loading for the problem on A/B testing.
# Returns a list of student backgrounds. Each student is a list
# with two elements: their id, their background.
def loadBackgrounds():
	reader = csv.reader(open('background.csv'))
	# this line skips the header at the top of the csv
	header = reader.next()
	learningOutcomes = []
	for row in reader:
		learningOutcomes.append(row)
	return learningOutcomes


# Example code for looping over a list in python. This 
# function prints out the list
def outputList(l):
	for row in l:
		print row
	print '\n----\n'

if __name__ == '__main__':
	main()